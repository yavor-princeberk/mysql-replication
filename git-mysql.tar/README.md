# mysql-replication
files for mysql replication
When the container is started 
rm -f /var/lib/mysql/ib* 
restart mysql 
