#!/bin/bash
git config --global user.email "yavor@princeberk.com"
git config --global user.name "yavor-princeberk"
