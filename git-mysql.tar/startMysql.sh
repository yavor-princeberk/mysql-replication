#!/bin/bash
/etc/init.d/mysql start 2>&1 > /dev/null
